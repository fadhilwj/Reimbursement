#ifndef MENU_H
#define MENU_H

#include <iostream>
#include <string>
#include "parent.h"

using namespace std;

int displayMenu();
string displayUpdateBiaya();
string displayHapusBiaya();

#endif
